TOKEN = "1540912756:AAE9V7MEaBabk5QggyS4cFFjD34ZzXw_1tA"


keys = {
    'доллар': 'USD',
    'евро': 'EUR',
    'биткоин': 'BTC',
    'рубль': 'RUB'
}